import os
import traceback

from btrdb_v4_api import btrdb_v4_api
from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_bcrypt import Bcrypt
import json
import argparse
from apscheduler.schedulers.background import BackgroundScheduler
from watchdog import watchdog
import ssl

root = os.path.dirname(os.path.abspath(__file__))

"""This http api is not designed for critical application. It may have security vulnerabilities. eg. CSRF"""

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite://///home/user/btrdb_proj/btrdb_api/authorization.db'
app.config['SECRET_KEY'] = b'\x9e\xb8@\xda@%\x8a\x9c\xc2-\x8c#K\xde\xffE'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
bcrypt = Bcrypt(app)

""" Define the user table. """
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(30), unique=True, nullable=False)
    email = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(20), nullable=False)
    
"""Define the permission tale. """
class Permission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(30), unique=False, nullable=False)
    stream = db.Column(db.String(80))
    permission = db.Column(db.String(1))

with open(os.path.join(root, 'abbreviations.txt')) as json_file:
    Abbrv = json.load(json_file)
    
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/info')
def info():
    return jsonify({'result':str(conn.info()).replace('\n', ' ')}), 200

@app.route('/signup', methods=['POST'])
def signup():
    try: 
        if request.method == 'POST' and request.json:
            req_data = json.loads(request.get_json())
            user_name = str(req_data['username'])
            email = str(req_data['email'])
            password = bcrypt.generate_password_hash(str(req_data['password'])).decode('utf-8')
            if User.query.filter_by(username = user_name).first():
                return "username already exists", 400
            # Should hash and salt password instead. Maybe modify this in the future.
            user = User(username=user_name, email=email, password=password)
            db.session.add(user)
            db.session.commit()
            return "succeeded", 200
        else:
            return "json is empty or did not use post", 400
    except Exception as e:
        return "Input in wrong format {}".format(e), 400

@app.route('/login', methods=['POST'])
def login():
    try:
        if request.method == 'POST' and request.json:
            req_data = json.loads(request.get_json())
            user_name = str(req_data['username'])
            password = str(req_data['password'])
            user = User.query.filter_by(username = user_name).first()
            if (user is None):
                return "User %s doesn't exist"%user_name, 400
            if bcrypt.check_password_hash(user.password, password):
                login_user(user, remember=True)
                return "User %s login succeeded" % user.username, 200
            return "Password and username doesn't match", 400
    except Exception as e:
        return "Input in wrong format {}".format(e), 400   
    
@app.route('/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    return "Your are now logged out.", 200

@app.route('/get_metadata/<keyname>', methods=['GET'])
@login_required
def get_metadata(keyname):
    keyname_split = keyname.split('_')
    stream_room = keyname_split[0]
    stream_type = keyname_split[1]
    stream_name = keyname_split[2]
    collection = "71T/%s/%s/%s" %(stream_room, Abbrv[stream_type], stream_name)
    result = conn.list_streams(collection, False, True)
    return jsonify({'result': str(result)}), 200
    
@app.route('/list_streams/<collection>', methods=['GET'])
@login_required
def list_streams(collection):
    result = conn.list_streams(collection.replace('_','/'), True, True)
    return jsonify({'result': str(result)}), 200

@app.route('/write_db', methods=['PUT'])
@login_required
def write_db():
    try:
        if request.method == 'PUT' and request.json:                            
            req_data = json.loads(request.get_json())
            if not Permission.query.filter_by(username=current_user.username, stream='SUDO', permission='s').first():
                for channelname in req_data.keys():
                    if not Permission.query.filter_by(username=current_user.username, stream=channelname, permission='w').first():
                        return "Not authorized to write stream %s"%channelname, 400
            for channelname in req_data.keys():
                data = list(req_data[channelname].items())
                data = list(map(lambda x: (int(int(x[0])*1e6), x[1]), data))
                stream = conn.create_stream(channelname)
                stream.insert(data)
                stream.flush() 
            return jsonify({}), 200
        else:
            return jsonify({'error':{'method':request.method, 'json':request.json}}), 405
    except Exception as e:
        return str(e), 400
    
@app.route('/read_window_db', methods=['GET'])
@login_required
def read_window_db():
    try:
        keynames = request.args.getlist('keynames')
        if not Permission.query.filter_by(username=current_user.username, stream='SUDO', permission='s').first():
            for channelname in keynames:
                if not Permission.query.filter_by(username=current_user.username, stream=channelname, permission='w').first() and not Permission.query.filter_by(username=current_user.username, stream=channelname, permission='r').first():
                    return "Not authorized to read stream %s"%channelname, 400
        start = request.args.get('start')
        end = request.args.get('end')
        ts = request.args.get('ts')
    except Exception as e:
        return 'Invalid Request Arguments {}'.format(e), 400
    try:
        result_data = conn.read_window_data(start, end, ts, keynames)
    except Exception as e:
        return 'Bad Request {}'.format(e), 400
    return result_data.to_json(date_unit='ms'), 200

@app.route('/read_raw_db', methods=['GET'])
@login_required
def read_raw_db():
    try:
        keynames = request.args.getlist('keynames')
        if not Permission.query.filter_by(username=current_user.username, stream='SUDO', permission='s').first():
            for channelname in keynames:
                if not Permission.query.filter_by(username=current_user.username, stream=channelname, permission='w').first() and not Permission.query.filter_by(username=current_user.username, stream=channelname, permission='r').first():
                    return "Not authorized to read stream %s"%channelname, 400
        start = request.args.get('start')
        end = request.args.get('end')
    except Exception as e:
        return 'Invalid Request Arguments {}'.format(e), 400
    try:
        result_data = conn.read_raw_data(start, end, keynames)
    except Exception as e:
        return 'Bad Request {}'.format(e), 400
    return result_data.to_json(date_unit='ms'), 200

@app.route('/delete_range_db', methods=['GET'])
@login_required
def delete_range_db():
    try:
        keynames = request.args.getlist('keynames')
        if not Permission.query.filter_by(username=current_user.username, stream='SUDO', permission='s').first():
            for channelname in keynames:
                if not Permission.query.filter_by(username=current_user.username, stream=channelname, permission='w').first():
                    return "Not authorized to read stream %s"%channelname, 400
        start = request.args.get('start')
        end = request.args.get('end')
    except Exception as e:
        return 'Invalid Request Arguments {}'.format(e), 400
    try:
        conn.delete_range(start, end, keynames)
    except Exception as e:
        return 'Bad Request {}'.format(e), 400
    return jsonify(success=True), 200

@app.route('/delete_streams', methods=['GET'])
@login_required
def delete_streams():
    try:
        keynames = request.args.getlist('keynames')
        if not Permission.query.filter_by(username=current_user.username, stream='SUDO', permission='s').first():
            for channelname in keynames:
                if not Permission.query.filter_by(username=current_user.username, stream=channelname, permission='w').first():
                    return "Not authorized to read stream %s"%channelname, 400
    except Exception as e:
        return 'Invalid Request Arguments {}'.format(e), 400
    try:
        conn.delete_stream(keynames)
    except Exception as e:
        return 'Bad Request {}'.format(e), 400
    return jsonify(success=True), 200

@app.route('/watchdog/add_stream', methods=['PUT'])
@login_required
def watchdog_addStream():
    try:
        if request.method == 'PUT' and request.json:
            streams = json.loads(request.get_json())
            for item in streams.items():
                stream = item[0]
                stucktime = item[1]['stucktime']
                missingtime = item[1]['missingtime']
                WD.add_stream(stream, stucktime=stucktime, missingtime=missingtime)
            return jsonify({}), 200
        else:
            return jsonify({'error':{'method':request.method, 'json':request.json}}), 405
    except Exception as e:
        return "Request json in wrong format {}".format(e), 400

@app.route('/watchdog/delete_stream', methods=['PUT'])
@login_required
def watchdog_deleteStream():
    try:
        if request.method == 'PUT' and request.json:
            streams = json.loads(request.get_json())
            watchdog_streams = WD.list_streams()
            nonexist_streams = []
            for stream in streams['streams']:
                if not stream in watchdog_streams:
                    nonexist_streams.append(stream)
            if len(nonexist_streams) > 0:
                return "Stream(s) %s does/do not exist" % nonexist_streams, 400
            for stream in streams['streams']:
                WD.delete_stream(stream)
            return jsonify({}), 200
        else:
            return jsonify({'error':{'method':request.method, 'json':request.json}}), 405
    except Exception as e:
        return "Request json in wrong format {}".format(e), 400
    
@app.route('/watchdog/add_room', methods=['PUT'])
@login_required
def watchdog_addRoom():
    try:
        if request.method == 'PUT' and request.json:
            rooms = json.loads(request.get_json())
            for room in rooms['rooms']:
                WD.add_room(room)
            return jsonify({}), 200
        else:
            return jsonify({'error':{'method':request.method, 'json':request.json}}), 405
    except Exception as e:
        return "Request json in wrong format {}".format(e), 400

@app.route('/watchdog/delete_room', methods=['PUT'])
@login_required
def watchdog_deleteRoom():
    try:
        if request.method == 'PUT' and request.json:
            rooms = json.loads(request.get_json())
            watchdog_rooms = WD.list_rooms()
            nonexist_rooms = []
            for room in rooms['rooms']:
                if not room in watchdog_rooms:
                    nonexist_rooms.append(room)
            if len(nonexist_rooms) > 0:
                return "Room(s) %s does/do not exist" % nonexist_rooms, 400
            for room in rooms['rooms']:
                WD.delete_room(room)
            return jsonify({}), 200
        else:
            return jsonify({'error':{'method':request.method, 'json':request.json}}), 405
    except Exception as e:
        return "Request json in wrong format {}".format(e), 400

if __name__=="__main__":
    # parse arguments
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", default=False, type=bool)
    parser.add_argument("--conn_address", default="71tdb.lbl.gov:4410")
    parser.add_argument("--swagger_address", default="https://71tdb.lbl.gov:444/v4")
    parser.add_argument("--watchdog", default= True, type=bool)
    parser.add_argument("--defaultstucktime", default= 60)
    parser.add_argument("--defaultmissingtime", default= 60)
    args = parser.parse_args()

    # build connection to BtrDB, start the Http API
    conn = btrdb_v4_api(args.conn_address, args.swagger_address)
    # Start the watchdog
    if (args.watchdog):
        WD = watchdog(args.conn_address, args.defaultstucktime, args.defaultmissingtime)
        scheduler = BackgroundScheduler()
        scheduler.add_job(WD.check, 'interval', seconds=15)
        scheduler.start()

    if args.debug:
        app.run(debug=True)
    else:
        context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
        context.load_cert_chain("/home/user/btrdb_proj/71tdb_lbl_gov_cert.crt", "/etc/ssl/private/71tdb.lbl.gov.key")
        app.run(host='0.0.0.0', port='9090', debug=False, ssl_context=context)
    
    
