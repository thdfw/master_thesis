from http_API import db, User, Permission
from os import path

"""create user table and permission table if doesn't exist."""
def db_init():
    if not path.exists('./authorization.db'):
        db.create_all()
    
"""add a permission record to Permission table.
   Args:
       username(str)
       stream_name(str)
       permission(str): 'w' for write, 'r' for read. Note that 'w' imply 'r'.
"""
def add_permission(username, stream_name, permission):
    db_init()
    record = Permission(username=username, stream=stream_name, permission=permission)
    db.session.add(record)
    db.session.commit()

"""add multiple permission records to Permission table.
   Args:
       username(str)
       tuple_list(List of tuples): List of (stream_name, permission) tuples.
"""
def add_permissions(username, tuple_list):
    for pair in tuple_list:
        add_permission(username, pair[0], pair[1])