from btrdb_v4_api import btrdb_v4_api 
from datetime import datetime, timedelta
import smtplib, ssl
import numpy as np
import pandas as pd
import email
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

class watchdog(object):
    def __init__(self, connection_address, default_stuckTime, default_missingTime):
        self.conn = btrdb_v4_api(connection_address)
        self.default_stuckTime = default_stuckTime
        self.default_missingTime = default_missingTime
        self.streams = {}
        self.alert = False
        self.rowlist = []
    
    def check(self):
        """ This function perform the checking process. It goes through all streams in the checklist and looks for any anomalies """
        self.alert = False
        endTime = datetime.now()
        startTime = endTime - timedelta(hours=1)
        streams = (self.streams.keys())
        if len(streams) == 0:
            return
        for stream in streams:
            #Check missing
            time_array = pd.date_range(startTime, endTime, freq=str(self.streams[stream][1])+'S')
            try:
                if_miss = list(map(lambda t: (pd.to_datetime(t) - pd.to_datetime(self.conn.nearest(stream, t)[0])).total_seconds() > self.streams[stream][1], time_array))
                if np.sum(if_miss) >= 1:
                    # Alert
                    self.alert = True
                    last_value = self.conn.nearest(stream, time_array[if_miss.index(True)])[1]
                    self.rowlist.append({'stream name': stream, 'last value': last_value, 'stuck value': float('nan'), 'error type': 'missing value'})
                    print('%s found missing values'%stream)
                    continue
            except ValueError as e1:
                # Alert
                self.alert = True
                self.rowlist.append({'stream name': stream, 'last value': float('nan'), 'stuck value': float('nan'), 'error type': 'stream does not exist'})
                print('stream %s does not exist'%stream)
                continue
            except Exception as e2:
                # Alert
                if (str(e2) == "[401] no such point"):
                    self.alert = True
                    self.rowlist.append({'stream name': stream, 'last value': float('nan'), 'stuck value': float('nan'), 'error type': 'missing value'})
                    print('%s found missing values'%stream)
                else:
                    print(e2)
                continue


            #Check for stuck values.
            array = self.conn.read_window_data(startTime, endTime, 's', [stream])[stream]
            num_stuck=0
            current = 0
            for i in array:
                if (num_stuck >= self.streams[stream][0]):
                    self.alert=True
                    self.rowlist.append({'stream name': stream, 'last value': float('nan'), 'stuck value': current, 'error type': 'stuck value'})
                    #Alert
                    print(stream, "got stuck")
                    break
                elif (i == current):
                    num_stuck += 1
                else:
                    current = i
                    num_stuck = 0

        if (self.alert):
            self.send_alert()
            self.rowlist = []       


    def add_stream(self, stream_name, stucktime=None, missingtime=None):
        """ Append a stream to the checklist
            Args: 
                stream_name(str)
                stucktime(int): the longest time in seconds that the stream's data can remain constant before triggering the warning.
                missingtime(int): the longest time in seconds that the stream's data can be missing before triggering the warning.
        """
        if (stucktime == None):
            stucktime = self.default_stuckTime
        if (missingtime == None):
            missingtime = self.default_missingTime
        self.streams[stream_name] = [stucktime, missingtime]

    def delete_stream(self, stream_name):
        """ Remove a stream from the checklist
            Args:
                stream_name(str)
        """
        if stream_name in self.streams:
            del self.streams[stream_name]
            
    def add_room(self, room_name):
        """  Add all streams in a room to the checklist
             Args:
             room_name(str)
        """
        
        for stream in self.conn.list_streams('71T/%s'%room_name, True, True):
            stream_name = stream['stream_name'].decode("utf-8")
            self.add_stream(stream_name)
    
    def delete_room(self, room_name):
        """  Remove all streams in a room to the checklist
             Args:
             room_name(str)
        """
        stream_names = list(self.streams.keys()).copy()
        for stream_name in stream_names:
            keyname_split = stream_name.split('_')
            stream_room = keyname_split[0]
            if (stream_room == room_name):
                del self.streams[stream_name]
    def list_rooms(self):
        """ List all rooms currently in the checklist"""
        return [stream_name.split('_')[0] for stream_name in self.streams.keys()]
    def list_streams(self):
        """ List all streams currently in the checklist"""
        return [stream_name for stream_name in self.streams.keys()]
    
    def send_alert(self):
        """ Send emails to the admin when observing anomalies"""
        port = 465  # For SSL
        smtp_server = "smtp.gmail.com"
        sender_email = "71tdbwatchdog@gmail.com"  # Enter your address
        receiver_email = "71tdbwatchdog@gmail.com"  # Enter receiver address
        password = "thisisfortesting"
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg['Subject'] = "Warning: 71T DAQ - Watchdog event detected"
        
        html = """\
        <html>
          <head></head>
          <body>
            {0}
          </body>
        </html>
        """.format(pd.DataFrame(self.rowlist).to_html())
        msg.attach(MIMEText(html, 'html'))
        
        #Create a secure SSL context
        context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
        context.load_cert_chain("/home/user/btrdb_proj/71tdb_lbl_gov_cert.crt", "/etc/ssl/private/71tdb.lbl.gov.key")

        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, msg.as_string())
            
            
