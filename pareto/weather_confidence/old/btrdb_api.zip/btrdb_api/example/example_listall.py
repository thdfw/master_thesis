import os
import sys
import json
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

from client import client

# Instantiate a client
c = client()

# Login
print(c.login_no_interactive('device1', '123456'))

# List streams
print('Which streams to display [71T/]: ', end='')
prefix = input()
streams = c.list_streams(prefix if prefix else '71T')
print(sorted([s['stream_name'] for s in streams]))

# delete all?
print('\n**** CAREFUL ****\nDo you want to delete streams? [y/[n]]: ', end='')
if input() == 'y':
    for s in streams:
        print('Delete "{}"? [y/[n]]: '.format(s['stream_name']), end='')
        if input() == 'y':
            print('-->deleted', c.delete_streams([s['stream_name']]))