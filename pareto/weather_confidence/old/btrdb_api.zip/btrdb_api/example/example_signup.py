import os
import sys
import json
import requests

sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

from db_manage import add_permission

# Sign up an account for this device. Replace with your own device account info here
payload = {'username':'device1', 'email':'device1@email.com', 'password': '123456'}
response = requests.post("https://71tdb.lbl.gov:9090/signup", json=json.dumps(payload))
print(response.status_code, response.text)

# notice we are giving the write permission to this device with 'w' here
#add_permission('device1', 'A_el_Power_W', 'w')
add_permission('device1', 'SUDO', 's')