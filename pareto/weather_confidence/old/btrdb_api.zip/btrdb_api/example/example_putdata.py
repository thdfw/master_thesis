import os
import sys
import json
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

from client import client

# Generate some random data
endTime = datetime.now()
startTime = endTime - timedelta(hours=10)
data = pd.DataFrame({}, index=pd.date_range(startTime, endTime, freq='S'))
data['Test1_el_Power3_W'] = np.where((data.index.minute<9) | (data.index.minute>58), 0, 35)

# Instantiate a client
c = client()

# Login
print(c.login_no_interactive('device1', '123456'))

# Upload the data
print(c.write_db(data))