import os
import sys
import time
import json
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

from client import client

# Instantiate a client
c = client()

# Login
print(c.login_no_interactive('device1', '123456'))

# Upload the data
while True:
    data = pd.DataFrame({}, index=[pd.to_datetime(datetime.now().replace(microsecond=0))])
    data['Test_th_Power1_W'] = np.random.random()
    data['Test_th_Power2_W'] = np.random.random()
    data['Test_th_Power3_W'] = np.random.random()
    print(data.index[0], c.write_db(data))
    time.sleep(5)