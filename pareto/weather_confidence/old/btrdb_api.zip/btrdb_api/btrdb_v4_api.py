import os
import json
import uuid
import binascii
import numpy as np
import pandas as pd
import requests as r

import btrdb4 as btrdb

root = os.path.dirname(os.path.abspath(__file__))

class btrdb_v4_api(object):
    def __init__(self, connection_address="71tdb.lbl.gov:4410", swagger_address="https://71tdb.lbl.gov:444/v4"):
        self.conn = btrdb.connect(connection_address)
        self.swagger_address = swagger_address
        with open(os.path.join(root, 'abbreviations.txt')) as json_file:
            self.abbrv_map = json.load(json_file)

    def Abbrv(self, key):
        if key in self.abbrv_map.keys():
            return self.abbrv_map[key]
        else:
            return key

    def info(self):
        """ Get connection info.
        
        """
        return self.conn.info()
    
    def list_streams(self, collection, prefix=False, showStreams=False):
        """ list all streams in a collection. 

        Args:
        collection(str): The collection to query
        prefix(bool): Whether the collection provided is a prefix. If so, query all collections that match the prefix.
        showsStream(bool): If the showStreams is true, return the stream label/keynames. Otherwise return the stream objects. 

        Returns:
        List[str/obj]: If the showStreams is true, return the stream label/keynames. Otherwise return the stream objects.
        """
        if showStreams:
            return [x.annotations()[0] for x in self.conn.lookupStreams(collection, prefix)]
        return list(self.conn.lookupStreams(collection, prefix))
        
    def get_stream(self, collection, stream_name):
        """Get the stream handler.
        
        Args:
        collection(str): Path of the stream. Example: 71T/Test/Electric
        stream_name(str): Name of the stream.
        
        Returns:
        obj: The stream object.
        """
        
        streams = self.list_streams(collection, False)
        streams = {str(s.annotations()[0]['stream_name']).replace("b'",'').replace("'",''): s for s in streams}
        if stream_name in streams.keys():
            return streams[stream_name]
        else:
            return None

    def create_stream(self, keyname):
        """Create a new stream given a keyname and uid.
        
        Args:
        keyname(str): The label/keyname of the stream. It needs to be in the format: {room}_{type}_{name}_{unit}
        
        Returns:
        obj: The stream objects created.
        """
        keyname_split = keyname.split('_')
        stream_room = keyname_split[0]
        stream_type = keyname_split[1]
        stream_name = keyname_split[2]
        stream_unit = keyname_split[3]
        #collection = "71T/%s/%s/%s" %(stream_room, self.Abbrv[stream_type], stream_name)
        collection = "71T/%s/%s" %(stream_room, self.Abbrv(stream_type))
        #streams = self.list_streams('/'.join([collection, stream_name]), False)
        stream = self.get_stream(collection, keyname)
        if not stream:
            uid = uuid.uuid4()
            stream = self.conn.create(uid, collection,
                             tags={"name":stream_name.encode('utf-8'), "unit": self.Abbrv(stream_unit).encode('utf-8')},
                             annotations = {"stream_name": keyname.encode('utf-8'), 'uuid':str(uid).encode('utf-8')})
            stream.flush()
        return stream

    def retrieve_uuid(self, keyname, uid_btrdb):
        """Retrieve uuid of a stream from the database.
        
        Args:
        keyname(str): The label/keyname of the stream. It needs to be in the format: {room}_{type}_{name}_{unit}
        
        Returns:
        str: uuid of the stream
        """
        keyname_split = keyname.split('_')
        stream_room = keyname_split[0]
        stream_type = keyname_split[1]
        stream_name = keyname_split[2]
        #collection = "71T/%s/%s/%s" %(stream_room, self.Abbrv[stream_type], stream_name)
        collection = "71T/%s/%s" %(stream_room, self.Abbrv(stream_type))
        post = {"collection": collection,
                "isCollectionPrefix": False,
                "tags": [],
                "annotations": []}
        response = r.post(self.swagger_address + "/lookupstreams", json=post)
        if response.text == '{"result":{}}\n':
            raise ValueError('stream %s does not exists.' % keyname)
        json_data = json.loads(response.text)

        for res in json_data['result']['results']:
            for a in res['annotations']:
                if a['key'] == 'uuid':
                    if a['value'] == uid_btrdb:
                        return res['uuid']
        return None

    def delete_stream(self, keynames):
        """Delete a list of streams
        
        Args:
        List[str]: A list of stream label/keynames to be deleted.
        
        Returns:
        None
        """
        for keyname in keynames:
            keyname_split = keyname.split('_')
            stream_room = keyname_split[0]
            stream_type = keyname_split[1]
            stream_name = keyname_split[2]
            #collection = "71T/%s/%s/%s" % (stream_room, self.Abbrv[stream_type], stream_name)
            collection = "71T/%s/%s" %(stream_room, self.Abbrv(stream_type))
            stream = self.get_stream(collection, keyname)
            if not stream:
                raise ValueError('stream %s does not exists.' % keyname)
            uid_btrdb = binascii.b2a_base64(stream.annotations()[0]['uuid']).decode().replace('\n','')
            uid = self.retrieve_uuid(keyname, uid_btrdb)
            response = r.post(self.swagger_address + "/obliterate", json={"uuid": uid})
            if response.status_code != 200:
                raise ValueError('stream %s error delete.' % keyname)

    def wirte_data(self, data):
        """Insert data into the Database
        
        Args: 
        data(Obj): Pandas DataFrame Object.
                   Indices are datetime objects. 
                   Columns are raw values with column names being the stream keyname/label.
        
        Returns:
        None
        """
        data.index = pd.to_datetime(data.index).astype(np.int64)
        for c in data.columns:
            x = data[c].reset_index().values.tolist()
            for i in range(len(x)):
                x[i][0] = int(x[i][0])
            stream = self.create_stream(c)
            stream.insert(x)
            stream.flush()
        return None

    def read_window_data(self, start, end, ts, keynames):
        """Read statistical aggregates of windows of data from BTrDB.
        
        Args:
        start(datetime-like str): Start time of the window (inclusive)
        end(datetime-like str): End time of the window (exclusive)
        ts(str): Width of datapoints. Can be 'd', 'h', 'min', 's', 'ms', 'ns', etc.
        keynames(List[str]): List of stream labels/keynames
        
        Returns:
        obj:Pandas DataFrame Object. 
            Indices are a datatime objects. 
            Columns are aggregated values with column names being the stream labels/keynames.
        """
        ts_dic = {'d': 'h', 'h':'min', 'min':'s', 's':'ms', 'ms':'ns', 'ns':'ns'}
        w = int(round(np.log2(int(pd.Timedelta(1, unit=ts_dic[ts]).asm8))))
        s = int(pd.Timestamp(start).asm8)
        e = int(pd.Timestamp(end).asm8)
        result_df = pd.DataFrame(index=pd.date_range(start, end, freq=ts))
        for keyname in keynames:
            keyname_split = keyname.split('_')
            stream_room = keyname_split[0]
            stream_type = keyname_split[1]
            stream_name = keyname_split[2]
            #collection = "71T/%s/%s/%s" % (stream_room, self.Abbrv[stream_type], stream_name)
            collection = "71T/%s/%s" %(stream_room, self.Abbrv(stream_type))
            #streams = self.list_streams(collection, False)
            stream = self.get_stream(collection, keyname)
            if not stream:
                raise ValueError('stream %s does not exists.' % keyname)
            df = pd.DataFrame(stream.alignedWindows(s, e, w))
            if (df.empty):
                raise ValueError('stream %s is currently empty.' % keyname)
            df['time'] = pd.to_datetime(df[0].apply(lambda p: p[0]))
            df['value'] = df[0].apply(lambda p: p[1])
            df = df.groupby('time').first()
            result_df = pd.concat([result_df, df['value']], axis=1)
            result_df.rename(columns={"value": keyname}, inplace=True)
        return result_df.interpolate().resample(ts).mean()
    
    def read_raw_data(self, start, end, keynames):
        """Read raw values of a stream from BTrDB
        
        Args: 
        start(datetime-like str): Start time of the window (inclusive)
        end(datetime-like str): End time of the window (exclusive)
        keynames(List[str]): The stream labels/keynames
        
        Returns:
        obj:Pandas DataFrame Object. 
            Indices are a datatime objects. 
            Columns are raw values with column names being the stream label/keyname.
        """
        result_df = pd.DataFrame({})
        for keyname in keynames:
            keyname_split = keyname.split('_')
            stream_room = keyname_split[0]
            stream_type = keyname_split[1]
            stream_name = keyname_split[2]
            #collection = "71T/%s/%s/%s" %(stream_room, self.Abbrv[stream_type], stream_name)
            collection = "71T/%s/%s" %(stream_room, self.Abbrv(stream_type))
            #streams = self.list_streams('/'.join([collection, stream_name]), False)
            stream = self.get_stream(collection, keyname)
            if not stream:
                raise ValueError('stream %s does not exists.' % keyname)
            df = pd.DataFrame(stream.rawValues(start=int(pd.Timestamp(start).asm8),
                                               end=int(pd.Timestamp(end).asm8)))
            if (df.empty):
                raise ValueError('stream %s data is unavaliable in this time window.' % keyname)
            df['time'] = pd.to_datetime(df[0].apply(lambda p: p[0]))
            df['value'] = df[0].apply(lambda p: p[1])
            df = df.groupby('time').first()
            result_df = pd.concat([result_df, df['value']], axis=1)
            result_df.rename(columns={"value": keyname}, inplace=True)
        return result_df

    def delete_range(self, start, end, keynames):
        """Delete data from a time range
        
        Args:
        start(datetime-like str): Start time of the window (inclusive)
        end(datetime-like str): End time of the window (exclusive)
        keynames(List[str]): The stream labels/keynames
        
        Returns:
        None
        """
        for keyname in keynames:
            keyname_split = keyname.split('_')
            stream_room = keyname_split[0]
            stream_type = keyname_split[1]
            stream_name = keyname_split[2]
            #collection = "71T/%s/%s/%s" %(stream_room, self.Abbrv[stream_type], stream_name)
            collection = "71T/%s/%s" %(stream_room, self.Abbrv(stream_type))
            #streams = self.list_streams('/'.join([collection, stream_name]), False)
            stream = self.get_stream(collection, keyname)
            if not stream:
                raise ValueError('stream %s does not exists.' % keyname)
            s = int(pd.Timestamp(start).asm8)
            e = int(pd.Timestamp(end).asm8)
            stream.deleteRange(s, e)
            stream.flush()
    
    def nearest(self, keyname, time, version=0, backward=True):
        """Finds the closest point in the stream to a specified time.
        
        Args:
        keynames(str): The stream label/keyname
        time(int): The time (in nanoseconds since Epoch) to search near
        backward(boolean): True to search backwards from time, else false for forward
        
        Returns:
        RawPoint: The point closest to time
        """
        keyname_split = keyname.split('_')
        stream_room = keyname_split[0]
        stream_type = keyname_split[1]
        stream_name = keyname_split[2]
        #collection = "71T/%s/%s/%s" %(stream_room, self.Abbrv[stream_type], stream_name)
        collection = "71T/%s/%s" %(stream_room, self.Abbrv(stream_type))
        #streams = self.list_streams('/'.join([collection, stream_name]), False)
        stream = self.get_stream(collection, keyname)
        if not stream:
            raise ValueError('stream %s does not exists.' % keyname)
        return stream.nearest(int(pd.Timestamp(time).asm8), version, backward)[0]
