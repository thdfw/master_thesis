# README #

BTrDB V4 API

### General ###
* This repository provides both server and local level API files to facilitate Pandas development on BTrDB (The Berkeley Tree DataBase).
* This library is developed based on the package [btrdb 4.11.2](https://pypi.org/project/btrdb/4.11.2/)
* This API has user authorization feature, which means only authorized users could interact with stream data in the BTrDB database.
* The API uses BTrDB to store the user-uploaded data, and uses sqlite3 database to store user account info.
* There are three main categories in this this library:
	* Sever/Host:
		* btrdb_v4_api.py: This files provides a functions to interact with the BTrDB installed on the sever. It is mainly used by http_api.py.
		* http_api.py: The http interface for outside http requests to access to the BTrDB on the sever.
		* abbreviations.txt: Abbrevaiations for type and unit of the streams.
		* watchdog.py: A python script that checks the status of the database with constant time interval.
		* authorization.db: A sqlite3 database that contains user account info. 
		* db_manage.py: This files contains a few neat functions to manage the sqlite3 database(authorization.db).
		* test_watchdog.ipynb: This is for test purpose only. You can simply ignore this file.
	* Local/Client: 
		* client.py: The client file used to communicate with the sever. 
	* Demo:
		* demo.ipynb: An interactive demo/tutorial on how to use the library.
	* Other:
		* requirements.txt: package requirements for setting up the api host.
		
### Virtue Environment (Recommanded But Optional) ###
* We want to create an isolated environment for this project so that it has its own dependencies, regardless of what the original python environment has installed. 
* Step-by-step Instruction
	* Log on to the sever
	* In terminal, run command ```$ python3 -m venv [env name]``` to create a new virtual environment. For the rest of the README file, I will assume that the virtual environment name is 'venv'.
	* run command ```$ source venv/bin/activate``` to activate this environment. 
	* When you are finished with this project, you can run ```$ deactivate``` to deactivate this environment.
	* For more information, please see [this](https://packaging.python.org/guides/installing-using-pip-and-virtual-environments/)

### Package Requirements ###

* Sever (btrdb_v4_api.py and/or http_api.py) 
	* run command ```$ pip3 install -r requirements.txt```
* Local (client.py)
	* run command ```$ pip3 install pandas```
* Demo (demo.py)
	* run command ```$ pip3 install -r requirements.txt```
	
### Getting Started ###
* Sever/Host:
	* Install the required packages(See Above)
	* Run command 
	
			$ sudo [Path To Your Python Interpreter] http_api.py --debug --conn_address --lookup_address --swagger_address --watchdog --defaultstucktime --defaultmissingtime
			
	  
		* There are six optional arguments:
			* --debug: Whether activate the debug mode. Default: False
			* --conn_address: The address and port of the BTrDB sever. Default: 71tdb.lbl.gov:4410
			* --swagger_address: The address and port of the swagger https api of the BTrDB. Default: https://71tdb.lbl.gov:444/v4
			* --watchdog: Whether activate the watchdog. Default: True
			* --defaultstucktime: The upper limit of the time in seconds that data can stay constant without triggering the warning. Default: 60
			* --defaultmissingtime: The upper limit of the time in seconds that data can be missing without trigging the warning. Default: 60
		* The sever now begin to listen to https requests.
		* For example, if we used the virtual environment 'venv' as mentioned in previous sections, we would run:
	  
	  			$ sudo venv/bin/python3 http_api.py --debug --conn_address --lookup_address --swagger_address --watchdog --defaultstucktime --defaultmissingtime
		
		* Note: Even if 'venv' is activate, it would be best if we explicityly specify the interpreter path because sudo command will use the default python interpreter in the system, which may not necessarily be the interpreter that we want to use.
	
	* Manage User Accounts
		* In the authorization.db, there are two tables: 
			* user: id|username|email|password (Note the password stored here is hashed)
			* permission: id|username|stream|permission (Permission is either 'w' or 'r')
		* Register a new user.
			1. The user first need to sign up a new user account by mothods introduced in the demo.ipynb.
			1. The admin then need to add a record to permission table for each stream that the user want to view or edit.
				* Open the terminal.
				* Go the directory which contains the db_manage.py.
				* Start a new Python3 session. 
				* Import the db_manage file and call the add_permission function with appropriate arguments (The function will automatically initiate a new authorization.db if it doesn't not yet exist.
				* For exmaple, if I want to give user Adam the permission to write to the stream 'A_el_Power_W', I would do the following in the python session:
				        
					    from db_manage import add_permission
					    add_permission('Adam', 'A_el_Power_W', 'w')
				  
				* Or if I want to give user Adam permissions to access multiple streams such as 'A_el_Power_W' and 'B_th_Window1_C' at once, I would use function add_permissions instead:
				  
				  		from db_manage import add_permission
					    add_permissions('Adam', [('A_el_Power_W', 'w'), ('B_th_Window1_C', 'r'])
						
		* Delete user account or deauthorization
			* In terminal: 
			```
			$ sqlite3 authorization.db
			```
				
			* Follow the sqlite3 syntax (more thorough tutorial [here](https://www.sqlitetutorial.net/sqlite-delete/)) to directly delete the user or permission records.
			* Examples: 
				* If I want to delete the user john from the user table, I would do:
			
						$ sqlite3 authorization.db
						sqlite> DELETE FROM user WHERE username = 'john';
				
				* If I want to stop user john from accessing stream "A_el_Power_W", I would do:
				
						$ sqlite3 authorization.db
						sqlite> DELETE FROM permission WHERE username = 'john' AND stream = 'A_el_Power_W';
						
		* WatchDog
			* See demo.ipynb for specific example of how to add/deleate streams from the watch list
			* You can customize the admin email directly in the watchdog.py in the section indicated by the comments.
					    
* Local/Client
	* Install the required packages (See Above)
	* There are three main ways to interact with the BtrDB database. 
		1. Mr.Plotter: https://71tdb.lbl.gov/
		1. Directly send https requests to the sever. Specific commands and examples are in demo.ipynb. 
		1. User client.py. Specfic commands and examples are also in demo.ipynb
	* The last two methods will require user login. Instructions on how to register are mentioned in the Manage User Accounts section above
	* There are technically other ways to interact with BTrDB, such as through btrdb_v4_api.py directly or Swagger UI. However, they are not the main focus of this library.
	
* Remote Device Usage Example
	* Assume the device name is "device1" and the stream is wants to gain access is "A_el_Power_W". The password we want to set is 123456. 
	* Sever Setup:
		* Log on to the sever.
		* Activate the python virtual environment if needed.
		* Go to the directory where requirements.txt is located in Terminal.
		* Run command ```$ pip3 install -r requirements.txt``` to install the required packages.
		* Run command ```$ nohup sudo ../venv/bin/python3 http_API.py &``` to start the api service of the sever.
		* Run command ```$ python3``` to start a new python session, and type the following:
	  
				from db_manage import add_permission
				import requests
				import json

				# Sign up an account for this device. Replace with your own device account info here
				payload = {'username':'device1', 'email':'device1@email.com', 'password': '123456'}
				response = requests.post("https://71tdb.lbl.gov:9090/signup", json=json.dumps(payload))

				# notice we are giving the write permission to this device with 'w' here
				add_permission('device1', 'A_el_Power_W', 'w')
	
	* Device Setup:
		* Now the device is ready to intereact with BTrDB. Here is an example script which uploads some randomly generated data into the stream A_el_Power_W:
	
				from btrdb_v4_api import btrdb_v4_api
				import pandas as pd
				import numpy as np
				from datetime import datetime, timedelta
				import json
				from client import client

				# Generate some random data
				endTime = datetime.now()
				startTime = endTime - timedelta(hours=10)
				data = pd.DataFrame({}, index=pd.date_range(startTime, endTime, freq='S'))
				data['A_el_Power_W'] = np.where((data.index.minute<9) | (data.index.minute>58), 0, 35)

				# Instantiate a client
				c = client()

				# Login
				c.login_no_interactive('device1', '123456')


				# Upload the data
				c.write_db(data)
			
		* For more avaliable functions and examples, please see demo.ipynb
	
### ###




### Stream Name Clarification ###

The stream names follow the following structure:  
\{room\}\_\{type\}\_\{name\}\_\{unit\} 

* Room: A, B, C, Weather
* Type(abbreviation): el (electric), th (thermal), il (illuminance), t (temperature)....  
* Name: short description, e.g., Plug, Light, Cool,...  
* Unit(abbreviation): W(Watt), C(Celsius)
* Examples:  
	A_el_Light_W  
	B_t_Window1_C   
	
To add more abbreviations, please directly edit the abbreviation.txt file


			

		