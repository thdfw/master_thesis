import os
import re
import time
import json
import random
import requests
import pandas as pd
from multiprocessing import Process

root = os.path.dirname(os.path.realpath(__file__))

RQ_TIMEOUT = 30 # s

def upload_worker(host_address, payload, cookies, timeout=RQ_TIMEOUT, max_retry=3):
    sleep = random.randint(10, 100) / 10.0
    time.sleep(sleep)
    success = False
    n = 0
    while not success:
        n += 1
        r = None
        try:
            r = requests.put("%s/write_db" % host_address, json=payload, cookies=cookies, timeout=timeout)
            success = True
        except:
            if n <= max_retry:
                time.sleep(sleep)
            else:
                success = True
                print('Could not upload data to btrdb. {}'.format(r))

class client(object):
    def __init__(self, host_address="https://71tdb.lbl.gov:9090",
                 abbr=os.path.join(root,'abbreviations.txt')):
        self.host_address = host_address
        self.cookies = None
        with open(abbr) as f:
            self.abbr = json.loads(f.read())

    def info(self):
        """ Get connection info.
        Returns:
        dict: response
        """
        response = requests.get("%s/info" %self.host_address, cookies=self.cookies, timeout=RQ_TIMEOUT)
        if response.status_code != 200:
            if response.status_code == 401:
                return "Not authorized/logged in"
            return response.text
        return response.json()
    
    def signup(self):
        """ Signup a new user
       
        Returns:
        Str: "success" / error message
        """
        def check(email):
            regex = '^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$'
            if(re.search(regex,email)):
                return True
            return False
        try:
            username = str(input("Enter a new username (30 characters max):"))
            if (not username):
                return "username should be non-empty"
            email = str(input("Enter email (30 characters max):"))
            if not check(email):
                return "invalid email address"
            password = str(input("Set a password:"))
            if (not password):
                return "password should be non-empty"
            confirm_password = str(input("Confirm your password:"))
            if (password != confirm_password):
                return "Error: confirm_password doesn't match password"
            payload = {'username':username, 'email':email, 'password': password}
            response = requests.post("%s/signup" % self.host_address, json=json.dumps(payload), timeout=RQ_TIMEOUT)
            if response.status_code != 200:
                return response.text
            self.cookies = None
            return response.text
        except Exception as e:
            return str(e)
        
    
    def login(self):
        """ Interactive login 
        
        Returns:
        Str: "success" /error message
        """
        try:
            username = str(input("Enter username:"))
            if (not username):
                return "username should be non-empty"
            password = str(input("Enter password:"))
            if (not password):
                return "password should be non-empty"
            payload = {'username':username, 'password': password}
            response = requests.post("%s/login" % self.host_address, json=json.dumps(payload), timeout=RQ_TIMEOUT)
            self.cookies = response.cookies
            return response.text
        except Exception as e:
            return str(e)
    
    def login_no_interactive(self, username, password):
        """ Login for without interactive input (such as remote devices)
        Args:
        username(str)
        password(str)
        Returns:
        Str: "success" /error message
        """
        try:
            payload = {'username':username, 'password': password}
            response = requests.post("%s/login" % self.host_address, json=json.dumps(payload), timeout=RQ_TIMEOUT)
            self.cookies = response.cookies
            return response.text
        except Exception as e:
            return str(e)
        
    def logout(self):
        """Logout current session
        Returns:
        Str: "success"/error message
        """
        response = requests.post("%s/logout" % self.host_address, cookies=self.cookies, timeout=RQ_TIMEOUT)
        if response.status_code != 200:
            if response.status_code == 401:
                return "Not authorized/logged in"
            return response.text
        self.cookies = None
        return response.text
        
    
    def get_metadata(self, streamName):
        """ Get connection info
        Args:
        streamName(str): The label/name of the stream. It needs to be in the format: {room}_{type}_{name}_{unit}
        Returns:
        dict: response
        """
        response = requests.get("%s/get_metadata/%s" % (self.host_address, streamName), cookies=self.cookies, timeout=RQ_TIMEOUT)
        if response.status_code != 200:
            if response.status_code == 401:
                return "Not authorized/logged in"
            return response.text
        return json.loads(response.json()['result'].replace("'",'"').replace('b"','"'))
        
    def list_streams(self, prefix='71T'):
        """ Get all streams
        Args:
        prefix(str): The prefix to search channels.
        Returns:
        dict: response
        """
        response = requests.get("%s/list_streams/%s" % (self.host_address, prefix.replace('/','_')), cookies=self.cookies, timeout=RQ_TIMEOUT)
        if response.status_code != 200:
            if response.status_code == 401:
                return "Not authorized/logged in"
            return response.text
        return json.loads(response.json()['result'].replace("'",'"').replace('b"','"'))
    
    def write_db(self, df, background=False):
        """Insert data into the Database

        Args: 
        df(Obj): Pandas DataFrame Object.
                   Indices are datetime objects. 
                   Columns are raw values with column names being the stream keyname/label.
        
        Returns:
        str: "success" / error message
        """
        payload = df.to_json()
        if background:
            uploader = Process(target=upload_worker, args=(self.host_address, payload, self.cookies, 10, 3))
            uploader.start()
            return "success"
        else:
            response = requests.put("%s/write_db" % self.host_address, json=payload, cookies=self.cookies, timeout=RQ_TIMEOUT)
            if response.status_code != 200:
                if response.status_code == 401:
                    return "Not authorized/logged in"
                return response.text
            return "success"
        
    def convert_tz_utc(self, timestamp, tz=int(time.timezone/3600.0)):
        return pd.to_datetime(timestamp).tz_localize('Etc/GMT+{}'.format(tz)).tz_convert('UTC').tz_localize(None)
        
    def convert_tz_local(self, timestamp, tz=int(time.timezone/3600.0)):
        return pd.to_datetime(timestamp).tz_localize('UTC').tz_convert('Etc/GMT+{}'.format(tz)).tz_localize(None)
    
    def read_window_db(self, start, end, ts, streamNames):
        """Read statistical aggregates of windows of data from BTrDB.
            Notice: Due to implementation limitations of btrdb4 package, the returned window will be an approximate.
            
            Args:
            start(datetime-like str): Start time of the window (inclusive)
            end(datetime-like str): End time of the window (exclusive)
            ts(str): Width of datapoints. Can be 'd', 'h', 'min', 's', 'ms', 'ns', etc.
            streamNames(List[str]): List of stream labels/streamNames
            
            Returns:
            obj:Pandas DataFrame Object. 
                epoch time in ms. 
                Columns are aggregated values with column names being the stream labels/streamNames.
                Or None if error.
        """ 
        payload = {'start': self.convert_tz_utc(start), 
            'end': self.convert_tz_utc(end),
            'ts': ts,
            'keynames' : streamNames
        }
        response = requests.get("%s/read_window_db" % self.host_address, params=payload, cookies=self.cookies, timeout=RQ_TIMEOUT)
        if response.status_code != 200:
            if response.status_code == 401:
                return "Not authorized/logged in"
            print(response.text)
            return pd.DataFrame()
        df = pd.DataFrame(response.json())
        df['date_time'] = self.convert_tz_local(pd.to_datetime(list(df.index), unit='ms'))
        df.set_index(keys='date_time', inplace=True)
        return df
    
    def read_raw_db(self, start, end, streamNames):
        """Read raw values of a stream from BTrDB
        
        Args: 
        start(datetime-like str): Start time of the window (inclusive)
        end(datetime-like str): End time of the window (exclusive)
        streamNames(List[str]): The stream labels/streamNames
        
        Returns:
        obj:Pandas DataFrame Object. 
            Indices are a datatime objects. 
            Columns are raw values with column names being the stream label/keyname.
            Or None if error
        """
        payload = {'start': self.convert_tz_utc(start), 
           'end': self.convert_tz_utc(end),
           'keynames': streamNames
        }
        response = requests.get("%s/read_raw_db" % self.host_address, params=payload, cookies=self.cookies, timeout=RQ_TIMEOUT)
        if response.status_code != 200:
            if response.status_code == 401:
                return "Not authorized/logged in"
            print(response.text)
            return pd.DataFrame()
        df = pd.DataFrame(response.json())
        df['date_time'] = self.convert_tz_local(pd.to_datetime(list(df.index), unit='ms'))
        df.set_index(keys='date_time', inplace=True)
        return df

    def delete_range_data(self, start, end, streamNames):
        """Delete data from a time range
        
        Args:
        start(datetime-like str): Start time of the window (inclusive)
        end(datetime-like str): End time of the window (exclusive)
        strNames(List[str]): The stream labels/keynames
        
        Returns:
        str: "success" / "error"
        """
        payload = {'start': self.convert_tz_utc(start), 
           'end': self.convert_tz_utc(end),
           'keynames': streamNames
        }
        response = requests.get("%s/delete_range_db" % self.host_address, params=payload, cookies=self.cookies, timeout=RQ_TIMEOUT)
        if response.status_code != 200:
            if response.status_code == 401:
                return "Not authorized/logged in"
            print(response.text)
            return "error"
        return "success"

    def delete_streams(self, streamNames):
        """Delete a list of streams
        
        Args:
        streamNames(list of str): A list of stream label/keynames to be deleted.
        
        Returns:
        str: "success" / "error"
        """
        payload = {'keynames': streamNames}
        response = requests.get("%s/delete_streams" % self.host_address, params=payload, cookies=self.cookies, timeout=RQ_TIMEOUT)
        if response.status_code != 200:
            if response.status_code == 401:
                return "Not authorized/logged in"
            print(response.text)
            return "Error"
        return "success"
        
    def unit_to_abbr(self, unit, default='-'):
        """Convert unit to abbreviation.
        
        Args:
        unit(str): The unit to be encoded.
        
        Returns:
        str: abbreviated unit
        """
        abbr = [k for k,v in self.abbr.items() if v == unit]
        if len(abbr) > 0:
            return abbr[0]
        else:
            return default
    
    def watchdog_addStream(self, payload):
        """ Add streams to watchdog checklist. If the stream is already on the checklist, modify the stucktime and missing time
        based on the passed in values.

        Args:
        payload(json): {
            '{stream_name1}' : {'stucktime': value in seconds
                                'missingtime': value in seconds}
            '{stream_name2}' : {'stucktime': value in seconds
                                'missingtime': value in seconds}
            ...
        }
        """

        response = requests.put("%s/watchdog/add_stream" % self.host_address, json=payload, cookies=self.cookies, timeout=RQ_TIMEOUT)
        if response.status_code != 200:
            if response.status_code == 401:
                return "Not authorized/logged in"
            return response.text
        return "success"

    def watchdog_deleteStream(self, payload):
        """ Delete streams from watchdog checklist

        Args:
        payload(json): {
            'streams' : [stream_name1, stream_name2, ...]
        }

        Returns:
        str: "success" / error message
        """

        response = requests.put("%s/watchdog/delete_stream" % self.host_address, json=payload, cookies=self.cookies, timeout=RQ_TIMEOUT)
        if response.status_code != 200:
            if response.status_code == 401:
                return "Not authorized/logged in"
            return response.text
        return "success"
    
    def watchdog_addRoom(self, payload):
        """ Add rooms to watchdog checklist. Stucktime and missingtime will use the default value.
        
        Args:
        payload(json): {
            'rooms' : [room1, room2, ...]
        }

        Returns:
        str: "success" / error message
        """
        response = requests.put("%s/watchdog/add_room" % self.host_address, json=payload, cookies=self.cookies, timeout=RQ_TIMEOUT)
        if response.status_code != 200:
            if response.status_code == 401:
                return "Not authorized/logged in"
            return response.text
        return "success"
    
    def watchdog_deleteRoom(self, payload):
        """ Delete rooms from watchdog checklist

        Args:
        payload(json): {
            'rooms' : [room1, room2, ...]
        }

        Returns:
        str: "success" / error message
        """

        response = requests.put("%s/watchdog/delete_room" % self.host_address, json=payload, cookies=self.cookies, timeout=RQ_TIMEOUT)
        if response.status_code != 200:
            if response.status_code == 401:
                return "Not authorized/logged in"
            return response.text
        return "success"
